import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_application_1/bloc/notes_bloc.dart';
import 'package:flutter_application_1/bloc/notes_event.dart';
import 'package:flutter_application_1/bloc/notes_state.dart';
import 'package:flutter_application_1/bloc/theme_bloc.dart';
import 'package:flutter_application_1/bloc/theme_event.dart';
import 'package:flutter_application_1/bloc/theme_state.dart';
import 'package:flutter_application_1/repositories/theme_repository.dart';
import 'package:flutter_application_1/screens/home_screen.dart';
import 'package:flutter_application_1/app_themes.dart';

class NotesApp extends StatelessWidget {
  final ThemeRepository themeRepository;

  const NotesApp({super.key, required this.themeRepository});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => ThemeBloc(themeRepository)..add(ThemeLoaded()),
        ),
        BlocProvider(
          create: (context) => NotesBloc()..add(LoadNotes()),
        ),
      ],
      child: BlocBuilder<ThemeBloc, ThemeState>(
        builder: (context, themeState) {
          return MaterialApp(
            title: 'Заметки',
            theme: AppThemes.lightTheme,
            darkTheme: AppThemes.darkTheme,
            themeMode: themeState.isDark ? ThemeMode.dark : ThemeMode.light,
            home: const HomeScreen(),
          );
        },
      ),
    );
  }
}
