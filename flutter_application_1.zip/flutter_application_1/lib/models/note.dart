class Note {
  final String id;
  final String content;
  final DateTime createdAt;
  final CardStyle cardStyle;

  Note({
    required this.id,
    required this.content,
    required this.createdAt,
    this.cardStyle = CardStyle.primary,
  });

  Note copyWith({
    String? id,
    String? content,
    DateTime? createdAt,
    CardStyle? cardStyle,
  }) {
    return Note(
      id: id ?? this.id,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      cardStyle: cardStyle ?? this.cardStyle,
    );
  }
}

enum CardStyle {
  primary,
  secondary,
  accent,
}