import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/note.dart';

class NoteDialog extends StatefulWidget {
  final Note? note;
  final Function(Note) onSave;
  final Function()? onDelete;

  const NoteDialog({
    super.key,
    this.note,
    required this.onSave,
    this.onDelete,
  });

  @override
  State<NoteDialog> createState() => _NoteDialogState();
}

class _NoteDialogState extends State<NoteDialog> {
  late TextEditingController _controller;
  CardStyle _selectedStyle = CardStyle.primary;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.note?.content ?? '');
    _selectedStyle = widget.note?.cardStyle ?? CardStyle.primary;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.note == null ? 'Новая заметка' : 'Редактировать заметку'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _controller,
            maxLines: 5,
            decoration: const InputDecoration(
              hintText: 'Введите текст заметки...',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          _buildStyleSelector(),
        ],
      ),
      actions: [
        if (widget.onDelete != null)
          TextButton(
            onPressed: () {
              widget.onDelete!();
              Navigator.of(context).pop();
            },
            child: Text(
              'Удалить',
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Отмена'),
        ),
        ElevatedButton(
          onPressed: _saveNote,
          child: const Text('Сохранить'),
        ),
      ],
    );
  }

  Widget _buildStyleSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Стиль карточки:',
          style: Theme.of(context).textTheme.labelMedium,
        ),
        const SizedBox(height: 8),
        Row(
          children: CardStyle.values.map((style) {
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: FilterChip(
                  label: Text(_getStyleName(style)),
                  selected: _selectedStyle == style,
                  onSelected: (selected) {
                    setState(() {
                      _selectedStyle = style;
                    });
                  },
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  String _getStyleName(CardStyle style) {
    switch (style) {
      case CardStyle.primary:
        return 'Основной';
      case CardStyle.secondary:
        return 'Второстепенный';
      case CardStyle.accent:
        return 'Акцентный';
    }
  }

  void _saveNote() {
    if (_controller.text.trim().isNotEmpty) {
      final note = Note(
        id: widget.note?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
        content: _controller.text.trim(),
        createdAt: widget.note?.createdAt ?? DateTime.now(),
        cardStyle: _selectedStyle,
      );
      widget.onSave(note);
      Navigator.of(context).pop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}