import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'settings_event.dart';
import 'settings_state.dart';

class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  SettingsBloc()
      : super(SettingsState(isDarkTheme: false, userName: "", showHints: true)) {
    on<LoadSettings>(_onLoadSettings);
    on<ToggleTheme>(_onToggleTheme);
    on<ChangeUserName>(_onChangeUserName);
    on<ToggleHints>(_onToggleHints);
  }

  Future<void> _onLoadSettings(
      LoadSettings event, Emitter<SettingsState> emit) async {
    final prefs = await SharedPreferences.getInstance();
    final isDark = prefs.getBool("isDarkTheme") ?? false;
    final name = prefs.getString("userName") ?? "";
    final hints = prefs.getBool("showHints") ?? true;

    emit(SettingsState(isDarkTheme: isDark, userName: name, showHints: hints));
  }

  Future<void> _onToggleTheme(
      ToggleTheme event, Emitter<SettingsState> emit) async {
    final newTheme = !state.isDarkTheme;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("isDarkTheme", newTheme);
    emit(state.copyWith(isDarkTheme: newTheme));
  }

  Future<void> _onChangeUserName(
      ChangeUserName event, Emitter<SettingsState> emit) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString("userName", event.userName);
    emit(state.copyWith(userName: event.userName));
  }

  Future<void> _onToggleHints(
      ToggleHints event, Emitter<SettingsState> emit) async {
    final newHints = !state.showHints;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("showHints", newHints);
    emit(state.copyWith(showHints: newHints));
  }
}
