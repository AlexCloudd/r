import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_application_1/repositories/theme_repository.dart';
import 'theme_event.dart';
import 'theme_state.dart';

class ThemeBloc extends Bloc<ThemeEvent, ThemeState> {
  final ThemeRepository _themeRepository;

  ThemeBloc(this._themeRepository) : super(const ThemeState()) {
    on<ThemeChanged>(_onThemeChanged);
    on<ThemeLoaded>(_onThemeLoaded);
  }

  void _onThemeChanged(ThemeChanged event, Emitter<ThemeState> emit) {
    _themeRepository.saveThemeMode(event.isDark);
    emit(state.copyWith(isDark: event.isDark));
  }

  void _onThemeLoaded(ThemeLoaded event, Emitter<ThemeState> emit) async {
    final isDark = await _themeRepository.getThemeMode();
    if (isDark != null) {
      emit(state.copyWith(isDark: isDark));
    }
  }
}