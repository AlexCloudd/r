import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:notes_app/models/note.dart';
import 'notes_event.dart';
import 'notes_state.dart';

class NotesBloc extends Bloc<NotesEvent, NotesState> {
  NotesBloc() : super(const NotesState()) {
    on<LoadNotes>(_onLoadNotes);
    on<AddNote>(_onAddNote);
    on<UpdateNote>(_onUpdateNote);
    on<DeleteNote>(_onDeleteNote);
    on<SearchNotes>(_onSearchNotes);
  }

  void _onLoadNotes(LoadNotes event, Emitter<NotesState> emit) {
    // В реальном приложении здесь была бы загрузка из базы данных
    emit(state.copyWith(status: NotesStatus.success));
  }

  void _onAddNote(AddNote event, Emitter<NotesState> emit) {
    final newNotes = List<Note>.from(state.notes)..add(event.note);
    emit(state.copyWith(
      notes: newNotes,
      filteredNotes: _filterNotes(newNotes, state.searchQuery),
    ));
  }

  void _onUpdateNote(UpdateNote event, Emitter<NotesState> emit) {
    final newNotes = state.notes.map((note) => 
      note.id == event.note.id ? event.note : note
    ).toList();
    emit(state.copyWith(
      notes: newNotes,
      filteredNotes: _filterNotes(newNotes, state.searchQuery),
    ));
  }

  void _onDeleteNote(DeleteNote event, Emitter<NotesState> emit) {
    final newNotes = state.notes.where((note) => note.id != event.id).toList();
    emit(state.copyWith(
      notes: newNotes,
      filteredNotes: _filterNotes(newNotes, state.searchQuery),
    ));
  }

  void _onSearchNotes(SearchNotes event, Emitter<NotesState> emit) {
    final filteredNotes = _filterNotes(state.notes, event.query);
    emit(state.copyWith(
      searchQuery: event.query,
      filteredNotes: filteredNotes,
    ));
  }

  List<Note> _filterNotes(List<Note> notes, String query) {
    if (query.isEmpty) return notes;
    return notes.where((note) => 
      note.content.toLowerCase().contains(query.toLowerCase())
    ).toList();
  }
}