import 'package:equatable/equatable.dart';
import 'package:flutter_application_1/models/note.dart';

class NotesState extends Equatable {
  final List<Note> notes;
  final List<Note> filteredNotes;
  final String searchQuery;
  final NotesStatus status;

  const NotesState({
    this.notes = const [],
    this.filteredNotes = const [],
    this.searchQuery = '',
    this.status = NotesStatus.initial,
  });

  NotesState copyWith({
    List<Note>? notes,
    List<Note>? filteredNotes,
    String? searchQuery,
    NotesStatus? status,
  }) {
    return NotesState(
      notes: notes ?? this.notes,
      filteredNotes: filteredNotes ?? this.filteredNotes,
      searchQuery: searchQuery ?? this.searchQuery,
      status: status ?? this.status,
    );
  }

  @override
  List<Object> get props => [notes, filteredNotes, searchQuery, status];
}

enum NotesStatus {
  initial,
  loading,
  success,
  failure,
}