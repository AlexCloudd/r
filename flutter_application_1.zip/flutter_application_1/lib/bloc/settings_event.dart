abstract class SettingsEvent {}

class LoadSettings extends SettingsEvent {}

class ToggleTheme extends SettingsEvent {}

class ChangeUserName extends SettingsEvent {
  final String userName;
  ChangeUserName(this.userName);
}

class ToggleHints extends SettingsEvent {}
