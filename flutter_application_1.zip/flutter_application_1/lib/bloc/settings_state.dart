class SettingsState {
  final bool isDarkTheme;
  final String userName;
  final bool showHints;

  SettingsState({
    required this.isDarkTheme,
    required this.userName,
    required this.showHints,
  });

  SettingsState copyWith({
    bool? isDarkTheme,
    String? userName,
    bool? showHints,
  }) {
    return SettingsState(
      isDarkTheme: isDarkTheme ?? this.isDarkTheme,
      userName: userName ?? this.userName,
      showHints: showHints ?? this.showHints,
    );
  }
}
