import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:notes_app/bloc/notes_bloc.dart';
import 'package:notes_app/bloc/theme_bloc.dart';
import 'package:notes_app/models/note.dart';
import 'package:notes_app/widgets/note_card.dart';
import 'package:notes_app/widgets/note_dialog.dart';
import 'package:notes_app/widgets/search_field.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Заметки'),
        actions: [
          BlocBuilder<ThemeBloc, ThemeState>(
            builder: (context, state) {
              return IconButton(
                icon: Icon(state.isDark ? Icons.light_mode : Icons.dark_mode),
                onPressed: () {
                  context.read<ThemeBloc>().add(ThemeChanged(!state.isDark));
                },
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: SearchField(
              onChanged: (query) {
                context.read<NotesBloc>().add(SearchNotes(query));
              },
            ),
          ),
          Expanded(
            child: BlocBuilder<NotesBloc, NotesState>(
              builder: (context, state) {
                final notes = state.searchQuery.isEmpty 
                  ? state.notes 
                  : state.filteredNotes;

                if (notes.isEmpty) {
                  return Center(
                    child: Text(
                      state.searchQuery.isEmpty 
                        ? 'Нет заметок' 
                        : 'Заметки не найдены',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: notes.length,
                  itemBuilder: (context, index) {
                    final note = notes[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: NoteCard(
                        note: note,
                        onTap: () => _showNoteDialog(context, note),
                        onDelete: () => _deleteNote(context, note.id),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showNoteDialog(context, null),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showNoteDialog(BuildContext context, Note? note) {
    showDialog(
      context: context,
      builder: (context) => NoteDialog(
        note: note,
        onSave: (updatedNote) {
          if (note == null) {
            context.read<NotesBloc>().add(AddNote(updatedNote));
          } else {
            context.read<NotesBloc>().add(UpdateNote(updatedNote));
          }
        },
        onDelete: note != null ? () => _deleteNote(context, note.id) : null,
      ),
    );
  }

  void _deleteNote(BuildContext context, String id) {
    context.read<NotesBloc>().add(DeleteNote(id));
  }
}