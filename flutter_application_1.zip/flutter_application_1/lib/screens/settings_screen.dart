import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/settings_bloc.dart';
import '../bloc/settings_event.dart';
import '../bloc/settings_state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsBloc, SettingsState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(title: const Text("Настройки")),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Тёмная тема"),
                    Switch(
                      value: state.isDarkTheme,
                      onChanged: (_) =>
                          context.read<SettingsBloc>().add(ToggleTheme()),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                TextField(
                  decoration: const InputDecoration(
                    labelText: "Ваше имя",
                    border: OutlineInputBorder(),
                  ),
                  controller: TextEditingController(text: state.userName),
                  onChanged: (value) =>
                      context.read<SettingsBloc>().add(ChangeUserName(value)),
                ),

                const SizedBox(height: 20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Показывать подсказки"),
                    Switch(
                      value: state.showHints,
                      onChanged: (_) =>
                          context.read<SettingsBloc>().add(ToggleHints()),
                    ),
                  ],
                ),

                if (state.showHints) ...[
                  const SizedBox(height: 20),
                  const Text(
                    "Подсказки: На данной странице можно изменить тему на темную или светлую, так же можно ввести в соответствующее поле любой текст",
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
