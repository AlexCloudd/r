import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/note.dart';

class AppThemes {
  static final ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: const ColorScheme.light(
      primary: Color(0xFF6200EE),
      secondary: Color(0xFF03DAC6),
      surface: Color(0xFFFFFFFF),
      background: Color(0xFFF5F5F5),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF6200EE),
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: Color(0xFF6200EE),
      foregroundColor: Colors.white,
    ),
    cardTheme: CardTheme(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    extensions: const <ThemeExtension<dynamic>>[
      NoteCardStyles(
        primary: CardStyleData(
          backgroundColor: Color(0xFFFFFFFF),
          shadowColor: Color(0x1A000000),
        ),
        secondary: CardStyleData(
          backgroundColor: Color(0xFFE3F2FD),
          shadowColor: Color(0x1A1976D2),
        ),
        accent: CardStyleData(
          backgroundColor: Color(0xFFE8F5E8),
          shadowColor: Color(0x1A388E3C),
        ),
      ),
    ],
  );

  static final ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: const ColorScheme.dark(
      primary: Color(0xFFBB86FC),
      secondary: Color(0xFF03DAC6),
      surface: Color(0xFF121212),
      background: Color(0xFF1E1E1E),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF1E1E1E),
      elevation: 0,
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: Color(0xFFBB86FC),
      foregroundColor: Colors.black,
    ),
    cardTheme: CardTheme(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    extensions: const <ThemeExtension<dynamic>>[
      NoteCardStyles(
        primary: CardStyleData(
          backgroundColor: Color(0xFF2D2D2D),
          shadowColor: Color(0x40000000),
        ),
        secondary: CardStyleData(
          backgroundColor: Color(0xFF1E3A5F),
          shadowColor: Color(0x40003A8F),
        ),
        accent: CardStyleData(
          backgroundColor: Color(0xFF1B4332),
          shadowColor: Color(0x40006F3C),
        ),
      ),
    ],
  );
}

class NoteCardStyles extends ThemeExtension<NoteCardStyles> {
  final CardStyleData primary;
  final CardStyleData secondary;
  final CardStyleData accent;

  const NoteCardStyles({
    required this.primary,
    required this.secondary,
    required this.accent,
  });

  CardStyleData getStyle(CardStyle style) {
    switch (style) {
      case CardStyle.primary:
        return primary;
      case CardStyle.secondary:
        return secondary;
      case CardStyle.accent:
        return accent;
    }
  }

  @override
  NoteCardStyles copyWith({
    CardStyleData? primary,
    CardStyleData? secondary,
    CardStyleData? accent,
  }) {
    return NoteCardStyles(
      primary: primary ?? this.primary,
      secondary: secondary ?? this.secondary,
      accent: accent ?? this.accent,
    );
  }

  @override
  NoteCardStyles lerp(ThemeExtension<NoteCardStyles>? other, double t) {
    if (other is! NoteCardStyles) {
      return this;
    }
    return NoteCardStyles(
      primary: primary.lerp(other.primary, t),
      secondary: secondary.lerp(other.secondary, t),
      accent: accent.lerp(other.accent, t),
    );
  }
}

class CardStyleData {
  final Color backgroundColor;
  final Color shadowColor;

  const CardStyleData({
    required this.backgroundColor,
    required this.shadowColor,
  });

  CardStyleData lerp(CardStyleData other, double t) {
    return CardStyleData(
      backgroundColor: Color.lerp(backgroundColor, other.backgroundColor, t)!,
      shadowColor: Color.lerp(shadowColor, other.shadowColor, t)!,
    );
  }
}