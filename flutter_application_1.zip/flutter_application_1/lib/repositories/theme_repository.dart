import 'package:shared_preferences/shared_preferences.dart';

class ThemeRepository {
  static const String _themeKey = 'theme_mode';

  Future<bool> saveThemeMode(bool isDark) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setBool(_themeKey, isDark);
  }

  Future<bool?> getThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_themeKey);
  }
}