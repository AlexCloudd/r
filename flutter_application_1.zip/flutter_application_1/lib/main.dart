import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_application_1/app.dart';
import 'package:flutter_application_1/repositories/theme_repository.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final themeRepository = ThemeRepository();
  
  runApp(NotesApp(themeRepository: themeRepository));
}