import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:notes_app/app.dart';
import 'package:notes_app/repositories/theme_repository.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final themeRepository = ThemeRepository();
  
  runApp(NotesApp(themeRepository: themeRepository));
}